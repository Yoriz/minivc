**MiniVC - a minimal mvc library, with zero frameworks attached.**

throw your code like laundry into three piles. let them pass messages and have triggers. life is grand.
